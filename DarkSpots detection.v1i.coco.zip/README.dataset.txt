# DarkSpots detection > 2024-12-25 9:56pm
https://universe.roboflow.com/u-jahnavi/darkspots-detection

Provided by a Roboflow user
License: CC BY 4.0

